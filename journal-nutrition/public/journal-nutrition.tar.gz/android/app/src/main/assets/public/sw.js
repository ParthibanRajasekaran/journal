/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "sql-wasm.wasm",
    "revision": "07fa4b342a34d3016ed9016d82e73f82"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "08960d13e7d118eb10ff4e9ea923a35d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a83e18c60cb699b649bdde84ee43c177"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3516c0e43b309c2f1cce722be0d94fca"
  }, {
    "url": "index.html",
    "revision": "7a0e8974f7fe1c68a4e2234fc864b395"
  }, {
    "url": "icon.svg",
    "revision": "680f0cdebb0602a2dfec839a7db16541"
  }, {
    "url": "icon-maskable.svg",
    "revision": "fde9542f4ef5f3e4f78a721034974379"
  }, {
    "url": "favicon.png",
    "revision": "1e5a1717940bb1b2b56998f94691de6f"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "cc647e18288c3214388480cec59e33ac"
  }, {
    "url": "assets/index-r0zLCYga.css",
    "revision": null
  }, {
    "url": "assets/index-C68RieKm.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "cc647e18288c3214388480cec59e33ac"
  }, {
    "url": "favicon.png",
    "revision": "1e5a1717940bb1b2b56998f94691de6f"
  }, {
    "url": "icon.svg",
    "revision": "680f0cdebb0602a2dfec839a7db16541"
  }, {
    "url": "pwa-192x192.png",
    "revision": "3516c0e43b309c2f1cce722be0d94fca"
  }, {
    "url": "pwa-512x512.png",
    "revision": "a83e18c60cb699b649bdde84ee43c177"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "08960d13e7d118eb10ff4e9ea923a35d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "892cd011708df056fa954772bd5146fd"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
